#ifndef __BUSCA_H__
#define __BUSCA_H__

#include "ArvoreAVL.h"

void busca_e_avaliar(tipo_no *raiz, int *chaves, int num_chaves);
int obter_contador_comparacoes();
void selecionar_amostra(int *chaves, int *amostra, int total, int amostra_size);
void mostrar_amostra_e_salvar(int *amostra, int tamanho, const char *nome_arquivo);
int* ler_numeros_e_selecionar_amostra(const char *nome_arquivo, int *tamanho_amostra);


#endif // __BUSCA_H__
