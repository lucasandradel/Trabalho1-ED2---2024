#ifndef __GERACAO_H__
#define __GERACAO_H__


#include <stdio.h>
#include <stdlib.h>
#include <time.h>


//prototipagem de funções
void gerar_numeros(int n, const char *nome_arquivo);

#endif //FIM __GERACAO_H__