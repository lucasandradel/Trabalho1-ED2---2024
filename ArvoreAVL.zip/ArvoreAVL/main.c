#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>  // Biblioteca para a função sleep, que faz o programa "dormir" por alguns segundos
#include "ArvoreAVL.h"
#include "Busca.h"

int main() {
    tipo_no *arvore = NULL; // Inicializa a árvore AVL como vazia

    const char *nome_arquivo = "arquivo_20000_3.txt"; // Nome do arquivo contendo os números

    // Mensagem e pausa antes de começar a inserção
    printf("*************************** Iniciando a inserção. O programa fará uma pausa de 3 segundos... ***************************\n\n");
    sleep(3);

    // Chama a função para ler os números do arquivo e inseri-los na árvore AVL
    arvore = ler_e_inserir(nome_arquivo, arvore);

    // Mensagem e pausa após a inserção
    printf("\n *************************** Inserção concluída. O programa fará uma pausa de 2 segundos... ***************************\n");
    sleep(2);

    // Imprime a árvore AVL após a inserção dos números
    printf("\n ***************************Árvore AVL após inserção dos números: ***************************\n");
    imprime(arvore);

    // Mensagem e pausa antes de preparar para a busca
    printf("\n*************************** Preparando para a busca. O programa fará uma pausa de 2 segundos... ***************************\n");
    sleep(2);

    // Chama a função para ler os números do arquivo e selecionar a amostra
    int tamanho_amostra;
    int *amostra = ler_numeros_e_selecionar_amostra(nome_arquivo, &tamanho_amostra);
    if (amostra == NULL) {
        // Se não conseguir obter a amostra, encerra o programa com erro
        return EXIT_FAILURE;
    }

    // Nome do arquivo onde a amostra será salva
    const char *nome_arquivo_amostra = "amostra_20000_3.txt";

    // Mostra os valores da amostra e salva em um arquivo
    mostrar_amostra_e_salvar(amostra, tamanho_amostra, nome_arquivo_amostra);

    // Mensagem e pausa antes de iniciar a busca
    printf("\n*************************** Iniciando a busca. O programa fará uma pausa de 2 segundos... ***************************\n");
    sleep(2);

    // Realiza a busca na árvore AVL usando a amostra e avalia o desempenho
    busca_e_avaliar(arvore, amostra, tamanho_amostra);

    // Mostra o número total de rotações realizadas na árvore AVL
    printf("\nNúmero total de rotações: %d\n", obter_contador_rotacoes());
    
    // Mostra a altura total da árvore AVL
    printf("Altura total da árvore: %d\n", altura_no(arvore));

    // Libera a memória alocada para a amostra
    free(amostra);

    // Retorna 0 para indicar que o programa terminou com sucesso
    return EXIT_SUCCESS;
}
